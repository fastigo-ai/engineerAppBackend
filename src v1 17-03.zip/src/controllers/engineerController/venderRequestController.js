import { Engineer } from "../../models/engineersModal.js";
import VendorOrder from "../../models/vendorOrderModal.js";
import { createAndMatchVendorOrder, acceptOrderService,rejectOrderService } from "../../services/vendorRequestService.js";
import { getDistanceInMeters } from "../../utils/distance.js";
import { latLngToCell, gridDisk } from "h3-js";
import { getIO } from "../../config/socket.js";
import { uploadToCloudinary } from "../../utils/uploadToCloudinary.js";
const H3_RESOLUTION = 8;
const SEARCH_RING_SIZE = 30;

export const servicableLocation = async (req, res) => {
  try {
    const { project_id, calls } = req.body;

    if (!Array.isArray(calls) || calls.length === 0) {
      return res.status(400).json({
        success: false,
        message: "Calls array is required and cannot be empty",
      });
    }

    const SERVICE_RADIUS = 20000; // 20 km
    const H3_RESOLUTION = 8;
    const RING_SIZE = 22;

    const callMap = new Map();
    const allRequiredCells = new Set();

    /* ----------------------------------------------------
       STEP 1: PREPARE H3 SEARCH AREAS
    ---------------------------------------------------- */
    for (const call of calls) {
      const { call_id, lat, lng } = call;

      if (typeof lat !== "number" || typeof lng !== "number") continue;

      try {
        const centerCell = latLngToCell(lat, lng, H3_RESOLUTION);
        const lookupCells = gridDisk(centerCell, RING_SIZE);

        callMap.set(call_id, { lat, lng, lookupCells });

        for (const cell of lookupCells) {
          allRequiredCells.add(cell);
        }
      } catch (err) {
        console.error(`H3 error for call ${call_id}`, err);
      }
    }

    /* ----------------------------------------------------
       STEP 2: SINGLE FAST DB QUERY
    ---------------------------------------------------- */
    const availableEngineers = await Engineer.find({
      isActive: true,
      isAvailable: true,
      isDeleted: false,
      isBlocked: false,
      isSuspended: false,
      h3Index: { $in: Array.from(allRequiredCells) }
    }).select("h3Index location").lean();

    /* ----------------------------------------------------
       STEP 3: GROUP ENGINEERS BY H3 CELL
    ---------------------------------------------------- */
    const cellToEngineers = new Map();

    for (const eng of availableEngineers) {
      if (!cellToEngineers.has(eng.h3Index)) {
        cellToEngineers.set(eng.h3Index, []);
      }
      cellToEngineers.get(eng.h3Index).push(eng);
    }

    /* ----------------------------------------------------
       STEP 4: FINAL SERVICEABILITY CHECK (EXACT DISTANCE)
    ---------------------------------------------------- */
    const serviceable = [];
    const non_serviceable = [];

    for (const call of calls) {
      const data = callMap.get(call.call_id);

      if (!data) {
        non_serviceable.push({ call_id: call.call_id, reason: "Invalid coordinates" });
        continue;
      }

      const { lat, lng, lookupCells } = data;
      let found = false;

      // Only check engineers inside candidate cells
      for (const cell of lookupCells) {
        const engineersInCell = cellToEngineers.get(cell);
        if (!engineersInCell) continue;

        for (const eng of engineersInCell) {
          const [engLng, engLat] = eng.location.coordinates;

          const distance = getDistanceInMeters(lat, lng, engLat, engLng);

          if (distance <= SERVICE_RADIUS) {
            found = true;
            break;
          }
        }

        if (found) break;
      }

      if (found) {
        serviceable.push({ call_id: call.call_id });
      } else {
        non_serviceable.push({ call_id: call.call_id });
      }
    }

    /* ----------------------------------------------------
       STEP 5: RESPONSE
    ---------------------------------------------------- */
    return res.status(200).json({
      success: true,
      project_id,
      meta: {
        total_calls: calls.length,
        serviceable_count: serviceable.length,
        non_serviceable_count: non_serviceable.length,
      },
      serviceable,
      non_serviceable,
    });

  } catch (err) {
    console.error("Bulk Serviceability Error:", err);
    return res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
};

export const getVendorRequests = async (req, res) => {
  try {
    const { vendor_id, call_id, location } = req.body;

    if (!vendor_id || !call_id) {
      return res.status(400).json({
        success: false,
        message: "vendor_id and call_id are required"
      });
    }

    if (
      !location ||
      !Array.isArray(location.coordinates) ||
      location.coordinates.length !== 2
    ) {
      return res.status(400).json({
        success: false,
        message: "Invalid location format"
      });
    }

    const result = await createAndMatchVendorOrder(req.body);

    if (!result.success) {
      return res.status(200).json({
        success: false,
        message: "No engineers available",
        orderId: result.order._id
      });
    }

    return res.status(200).json({
      success: true,
      matchType: "H3_GEO_MATCH",
      orderId: result.order._id,
      results: {
        totalFound: result.matchedEngineers.length
      },
      matchedEngineers: result.matchedEngineers
    });

  } catch (err) {
    console.error("Match Error:", err);
    return res.status(500).json({
      success: false,
      message: "Internal server error"
    });
  }
};

export const acceptVendorOrder = async (req, res) => {
  try {
    const { orderId, distance } = req.body;
    const engineerId = req.user.id;

    if (!orderId) {
      return res.status(400).json({ 
        success: false, 
        message: "OrderId is required" 
      });
    }

    // Call the service
    const order = await acceptOrderService({
      orderId,
      engineerId,
      distance
    });


    // 🔔 SOCKET (Handle after successful service execution)
    const io = getIO();
    const orderRoom = `order_${order._id}`;

    // Notify winner
    io.to(engineerId.toString()).emit("ORDER_CONFIRMED", { 
      order_id: order._id 
    });

    // Close for everyone else
    io.to(orderRoom).emit("ORDER_CLOSED", { 
      order_id: order._id 
    });

    return res.status(200).json({ 
      success: true, 
      order 
    });

  } catch (err) {
    console.error("Accept Order Controller Error:", err);
    
    // Send specific status code if thrown by service, else default to 500
    const statusCode = err.status || 500;
    return res.status(statusCode).json({
      success: false,
      message: err.message || "Internal server error"
    });
  }
};

export const rejectVendorOrder = async (req, res) => {
  try {
    const { orderId } = req.body;
    const engineerId = req.user.id;

    // 1. Call the service to update the Database
    const order = await rejectOrderService({ orderId, engineerId });

    // 2. SOCKET: Remove this engineer from the order room 
    const io = getIO();
    const engineerRoom = engineerId.toString();
    const orderRoom = `order_${orderId}`;
    
    io.in(engineerRoom).socketsLeave(orderRoom);

    return res.status(200).json({ 
      success: true, 
      message: "Order rejected and removed from your feed" 
    });

  } catch (err) {
    console.error("Reject Order Controller Error:", err);
    const statusCode = err.status || 500;
    return res.status(statusCode).json({
      success: false,
      message: err.message || "Internal server error"
    });
  }
};

export const getNearbyVendorOrders = async (req, res) => {
  try {
    const engineerId = req.user.id;
    const { latitude, longitude } = req.query;

    if (!latitude || !longitude) {
      return res.status(400).json({
        success: false,
        message: "Latitude and longitude are required"
      });
    }

    const latNum = parseFloat(latitude);
    const lngNum = parseFloat(longitude);

    // 1. Get the H3 cell and neighboring hexagons
    const centerCell = latLngToCell(latNum, lngNum, H3_RESOLUTION);
    const searchCells = gridDisk(centerCell, SEARCH_RING_SIZE);

    // 2. Find orders
    const nearbyOrders = await VendorOrder.find({
      status: "PENDING",
      h3Index: { $in: searchCells },
      assigned_engineer_id: null,    
      rejected_engineers: { $ne: engineerId } 
    })
    .sort({ created_at: -1 }) 
    .limit(20)
    .lean();

    // 3. Map through orders to add calculated distance to each
    const ordersWithDistance = nearbyOrders.map(order => {
      // In MongoDB, coordinates are usually [lng, lat]
      const orderLng = order.location.coordinates[0];
      const orderLat = order.location.coordinates[1];

      const distanceInMeters = getDistanceInMeters(
        latNum, 
        lngNum, 
        orderLat, 
        orderLng
      );

      return {
        ...order,
        distance: (distanceInMeters / 1000).toFixed(2), // Convert to KM with 2 decimals
        distanceUnit: "km"
      };
    });

    // 4. (Optional) Sort by closest distance after calculation
    ordersWithDistance.sort((a, b) => a.distance - b.distance);

    return res.status(200).json({
      success: true,
      count: ordersWithDistance.length,
      orders: ordersWithDistance,
    });
  } catch (err) {
    console.error("H3 Nearby Orders Error:", err);
    return res.status(500).json({
      success: false,
      message: "Internal server error"
    });
  }
};

export const updateVendorOrderWorkStatus = async (req, res) => {
  try {
    const { orderId } = req.params;
    const { workStatus } = req.body;
    const engineerId = req.user.id;
    if (!["NOT_STARTED", "IN_PROGRESS", "COMPLETED","STARTED"].includes(workStatus)) {
      return res.status(400).json({
        success: false,
        message: "Invalid work status value"
      });
    }
    
    const order = await VendorOrder.findOneAndUpdate(
      { _id: orderId, assigned_engineer_id: engineerId },
      { work_status: workStatus },
      { new: true }
    );

    if (!order) {
      return res.status(404).json({
        success: false,
        message: "Order not found or not assigned to this engineer"
      });
    }

    return res.status(200).json({
      success: true,
      message: "Work status updated successfully",
      data: order
    });
  } catch (err) {
    console.error("Update Work Status Error:", err);
    return res.status(500).json({
      success: false,
      message: "Internal server error"
    });
  }
};

export const completeOrder = async (req, res) => {
  try {
    const { orderId } = req.body;
    const engineerId = req.user.id;
    const files = req.files; 

    // 1. Basic Validation
    if (!orderId) return res.status(400).json({ success: false, message: "Order ID is required." });
    if (!files || files.length === 0) {
      return res.status(400).json({ success: false, message: "Please upload at least one completion image." });
    }

    // 2. Parallel Upload to Cloudinary
    // We map over req.files and call your utility for each buffer
    const uploadResults = await Promise.all(
      files.map(file => uploadToCloudinary(file.buffer, "order_completions"))
    );

    // Extract only the URLs for the database
    const imageUrls = uploadResults.map(result => result.url);

    // 3. Update Order Status and Save Image URLs
    const order = await VendorOrder.findOneAndUpdate(
      { 
        _id: orderId, 
        assigned_engineer_id: engineerId, 
        status: "ACCEPTED" 
      },
      { 
        $set: { 
          status: "COMPLETED", 
          work_status: "COMPLETED",
          completed_at: new Date(),
          completion_images: imageUrls // Store the array of Cloudinary URLs
        } 
      },
      { new: true }
    );

    if (!order) {
      return res.status(404).json({ 
        success: false, 
        message: "Order not found or you aren't authorized to complete it." 
      });
    }

    // 4. Update Engineer Availability
    await Engineer.findByIdAndUpdate(engineerId, { isAvailable: true });

    // 5. Notify Vendor Webhook (Standard Payload)
    const webhookPayload = {
      call_id: order.call_id,
      status: "COMPLETED",
      completed_at: order.completed_at,
      proof_images: imageUrls
    };

    // Fire-and-forget or await depending on vendor reliability
    // axios.post("https://door2fyvendor-gv4g4.ondigitalocean.app/calls/engineer/assignment-result", webhookPayload)
    //   .catch(err => console.error("Vendor Webhook Error:", err.message));

    return res.status(200).json({
      success: true,
      message: "Job completed successfully!",
      order
    });

  } catch (err) {
    console.error("Complete Order Error:", err);
    res.status(500).json({ success: false, message: err.message || "Internal server error" });
  }
};


